// TheSalesSherpa Landing Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize page
    initializeAnimations();
    initializeFormTracking();
    trackPageView();
});

// Navigation Functions
function scrollToSignup() {
    document.getElementById('signup').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
    trackEvent('cta_click', { location: 'hero' });
}

function scrollToDemo() {
    document.getElementById('demo').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
    trackEvent('demo_click', { location: 'hero' });
}

// Mobile Menu Toggle
function toggleMobileMenu() {
    const navLinks = document.querySelector('.nav-links');
    const toggle = document.querySelector('.mobile-menu-toggle');
    
    navLinks.classList.toggle('mobile-open');
    toggle.classList.toggle('active');
}

// FAQ Toggle Function
function toggleFAQ(element) {
    const answer = element.nextElementSibling;
    const toggle = element.querySelector('.faq-toggle');
    const isOpen = answer.classList.contains('open');
    
    // Close all other FAQ items
    document.querySelectorAll('.faq-answer.open').forEach(item => {
        if (item !== answer) {
            item.classList.remove('open');
            item.previousElementSibling.querySelector('.faq-toggle').textContent = '+';
        }
    });
    
    // Toggle current item
    if (isOpen) {
        answer.classList.remove('open');
        toggle.textContent = '+';
    } else {
        answer.classList.add('open');
        toggle.textContent = '−';
        trackEvent('faq_open', { question: element.querySelector('h3').textContent });
    }
}

// Pricing Plan Selection
function selectPlan(planType) {
    trackEvent('plan_select', { plan: planType });
    
    if (planType === 'enterprise') {
        // Redirect to contact form or show modal
        showContactModal();
    } else {
        // Pre-fill signup form with plan info
        const teamSizeMap = {
            'solo': 'solo',
            'team': 'small'
        };
        
        document.getElementById('teamSize').value = teamSizeMap[planType] || '';
        scrollToSignup();
    }
}

// Contact Modal for Enterprise
function showContactModal() {
    // Create modal dynamically
    const modal = document.createElement('div');
    modal.className = 'contact-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>Contact Enterprise Sales</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p>Let's discuss your enterprise needs and create a custom solution.</p>
                <form id="contactForm" onsubmit="handleContactForm(event)">
                    <input type="text" placeholder="Full Name" required>
                    <input type="email" placeholder="Work Email" required>
                    <input type="text" placeholder="Company" required>
                    <input type="tel" placeholder="Phone Number" required>
                    <select required>
                        <option value="">Company Size</option>
                        <option value="50-100">50-100 employees</option>
                        <option value="100-500">100-500 employees</option>
                        <option value="500-1000">500-1000 employees</option>
                        <option value="1000+">1000+ employees</option>
                    </select>
                    <textarea placeholder="Tell us about your sales challenges..." rows="4"></textarea>
                    <button type="submit" class="contact-submit">Schedule Demo</button>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Add modal styles
    const style = document.createElement('style');
    style.textContent = `
        .contact-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem;
            border-bottom: 1px solid #e1e5e9;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #999;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-body form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .modal-body input,
        .modal-body select,
        .modal-body textarea {
            padding: 12px 16px;
            border: 1px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
        }
        
        .contact-submit {
            background: #FF6B35;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        
        .contact-submit:hover {
            background: #E55A2B;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
}

function closeModal() {
    const modal = document.querySelector('.contact-modal');
    if (modal) {
        modal.remove();
        document.body.style.overflow = '';
    }
}

// Form Submission Handlers
function handleSignup(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = {
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
        email: formData.get('email'),
        company: formData.get('company'),
        teamSize: formData.get('teamSize'),
        currentCrm: formData.get('currentCrm') || 'none'
    };
    
    // Validate required fields
    if (!data.firstName || !data.lastName || !data.email || !data.company || !data.teamSize) {
        showNotification('Please fill in all required fields.', 'error');
        return;
    }
    
    // Email validation
    if (!isValidEmail(data.email)) {
        showNotification('Please enter a valid work email address.', 'error');
        return;
    }
    
    // Show loading state
    const button = event.target.querySelector('.signup-button');
    const originalText = button.innerHTML;
    button.innerHTML = 'Creating Your Account...';
    button.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Track successful signup
        trackEvent('signup_complete', data);
        
        // Show success message
        showNotification('🎉 Welcome to TheSalesSherpa! Check your email for next steps.', 'success');
        
        // Reset form
        event.target.reset();
        button.innerHTML = originalText;
        button.disabled = false;
        
        // In a real app, you would:
        // 1. Send data to your backend API
        // 2. Create user account
        // 3. Send welcome email
        // 4. Redirect to onboarding
        
        console.log('Signup data:', data);
        
    }, 2000);
}

function handleContactForm(event) {
    event.preventDefault();
    
    const button = event.target.querySelector('.contact-submit');
    button.textContent = 'Scheduling...';
    button.disabled = true;
    
    setTimeout(() => {
        trackEvent('enterprise_contact', { form: 'modal' });
        showNotification('Thank you! Our enterprise team will contact you within 24 hours.', 'success');
        closeModal();
    }, 1500);
}

// Utility Functions
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            ${message}
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">&times;</button>
        </div>
    `;
    
    // Add notification styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10001;
                animation: slideInRight 0.3s ease;
                max-width: 400px;
            }
            
            .notification-content {
                background: white;
                border-radius: 8px;
                padding: 1rem 1.5rem;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                border-left: 4px solid #FF6B35;
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .notification-success .notification-content {
                border-left-color: #22c55e;
                background: #f0fdf4;
            }
            
            .notification-error .notification-content {
                border-left-color: #ef4444;
                background: #fef2f2;
            }
            
            .notification-close {
                background: none;
                border: none;
                font-size: 1.2rem;
                cursor: pointer;
                color: #999;
                padding: 0;
                line-height: 1;
            }
            
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Analytics and Tracking
function trackPageView() {
    // In a real app, you would integrate with Google Analytics, Mixpanel, etc.
    console.log('Page view tracked:', window.location.href);
}

function trackEvent(eventName, properties = {}) {
    // In a real app, you would send this to your analytics service
    console.log('Event tracked:', eventName, properties);
    
    // Example integration with Google Analytics
    if (typeof gtag !== 'undefined') {
        gtag('event', eventName, properties);
    }
    
    // Example integration with Mixpanel
    if (typeof mixpanel !== 'undefined') {
        mixpanel.track(eventName, properties);
    }
}

// Initialize Animations
function initializeAnimations() {
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll('.benefit-card, .testimonial, .pricing-card, .security-feature');
    animateElements.forEach(el => observer.observe(el));
    
    // Add CSS for animations
    const animationStyle = document.createElement('style');
    animationStyle.textContent = `
        .benefit-card, .testimonial, .pricing-card, .security-feature {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }
        
        .animate-in {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }
    `;
    document.head.appendChild(animationStyle);
}

// Form Field Tracking
function initializeFormTracking() {
    const emailField = document.getElementById('email');
    const companyField = document.getElementById('company');
    
    if (emailField) {
        emailField.addEventListener('blur', function() {
            if (this.value && isValidEmail(this.value)) {
                trackEvent('email_entered', { email_domain: this.value.split('@')[1] });
            }
        });
    }
    
    if (companyField) {
        companyField.addEventListener('blur', function() {
            if (this.value) {
                trackEvent('company_entered', { company: this.value });
            }
        });
    }
}

// Scroll-based Navigation Highlighting
window.addEventListener('scroll', function() {
    const sections = ['benefits', 'demo', 'pricing', 'faq'];
    const navLinks = document.querySelectorAll('.nav-links a');
    
    sections.forEach((sectionId, index) => {
        const section = document.getElementById(sectionId);
        if (section) {
            const rect = section.getBoundingClientRect();
            const isVisible = rect.top <= 100 && rect.bottom >= 100;
            
            if (isVisible) {
                navLinks.forEach(link => link.classList.remove('active'));
                const correspondingLink = document.querySelector(`.nav-links a[href="#${sectionId}"]`);
                if (correspondingLink) {
                    correspondingLink.classList.add('active');
                }
            }
        }
    });
});

// Add active nav link styles
const navStyle = document.createElement('style');
navStyle.textContent = `
    .nav-links a.active {
        color: var(--primary-orange) !important;
        font-weight: 600;
    }
    
    @media (max-width: 768px) {
        .nav-links.mobile-open {
            display: flex;
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            flex-direction: column;
            padding: 1rem;
            box-shadow: var(--shadow-lg);
            border-top: 1px solid var(--border-color);
        }
        
        .mobile-menu-toggle.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        
        .mobile-menu-toggle.active span:nth-child(2) {
            opacity: 0;
        }
        
        .mobile-menu-toggle.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -6px);
        }
    }
`;
document.head.appendChild(navStyle);

// Keyboard Accessibility
document.addEventListener('keydown', function(e) {
    // Close modal on Escape key
    if (e.key === 'Escape') {
        const modal = document.querySelector('.contact-modal');
        if (modal) {
            closeModal();
        }
    }
});

// Performance Monitoring
function measurePageLoadTime() {
    window.addEventListener('load', function() {
        const loadTime = performance.now();
        trackEvent('page_load_time', { load_time: Math.round(loadTime) });
    });
}

measurePageLoadTime();

// Prevent form resubmission on page refresh
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}